import {NextResponse, type NextRequest} from 'next/server'
import {getResourceTypeByTab} from '@/lib/resourceTypes'

/**
 * Old Resource Center filter links (/resource-center?tab=blog, the live site's
 * format) permanently redirect to the clean listing URL (/blogs). Any other
 * query parameters (e.g. ?category=) are kept.
 */
export function proxy(request: NextRequest) {
  const type = getResourceTypeByTab(request.nextUrl.searchParams.get('tab'))
  if (!type) return NextResponse.next()
  const url = request.nextUrl.clone()
  url.pathname = type.basePath
  url.searchParams.delete('tab')
  return NextResponse.redirect(url, 301)
}

export const config = {
  matcher: '/resource-center',
}
