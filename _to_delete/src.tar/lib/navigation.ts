/**
 * Main navigation (hard-coded for the demo).
 * Sub-links and URLs are copied from the live goiguide.com nav (checked 2026-10-06).
 */
export type NavLink = {label: string; href: string}
export type NavItem = {label: string; href?: string; children?: NavLink[]}

export const mainNav: NavItem[] = [
  {
    label: 'Solutions',
    children: [
      {label: 'Floor Plans', href: '/iguide/floor-plans'},
      {label: '3D Virtual Tours', href: '/iguide/3d-virtual-tours'},
      {label: 'CAD Deliverables', href: '/iguide/cad-deliverables'},
      {label: 'Xactimate Sketches', href: '/iguide/xactimate-sketches'},
      {label: 'Site Plans', href: '/iguide/site-plans'},
      {label: 'Integrations', href: '/iguide/integrations'},
      {label: 'Capture Hardware', href: '/camera-hardware'},
      {label: 'Find an iGUIDE Pro', href: 'https://ion.goiguide.com/'},
    ],
  },
  {
    label: 'Who We Serve',
    children: [
      {label: 'Residential Real Estate', href: '/residential-real-estate'},
      {label: 'Real Estate Photography', href: '/real-estate-photography'},
      {label: 'Architecture & Remodeling', href: '/architecture-engineering-construction'},
      {label: 'Design & Construction', href: '/design-construction'},
      {label: 'Insurance & Restoration', href: '/insurance-restoration'},
      {label: 'Forensic Investigation', href: '/forensic-investigation'},
      {label: 'Facility Management', href: '/facility-management'},
    ],
  },
  {
    label: 'Resources',
    children: [
      {label: 'Customer Stories', href: '/customer-stories'},
      {label: 'Blog', href: '/blogs'},
      {label: 'Webinars', href: '/webinars'},
      {label: 'Videos', href: '/video'},
      {label: 'Brochures', href: '/brochures'},
      {label: 'News', href: '/news'},
      {label: 'White Papers & eBooks', href: '/white-papers-and-ebooks'},
      {label: 'Training & Support', href: 'https://help.youriguide.com'},
      {
        label: 'Marketing Catalogue',
        href: 'https://help.youriguide.com/hc/en-us/articles/28225392683154-iGUIDE-Marketing-Catalogue',
      },
      {label: 'Downloads', href: '/downloads'},
      {label: 'iGUIDE Gallery', href: '/resources-and-media/iguide-gallery'},
    ],
  },
  {label: 'Support', href: 'https://help.youriguide.com'},
  {label: 'Pricing', href: '/pricing'},
]

export const headerButtons = {
  findPro: {label: 'Find a pro', href: 'https://ion.goiguide.com/'},
  shop: {label: 'Shop Now', href: 'https://store.goiguide.com/'},
}
