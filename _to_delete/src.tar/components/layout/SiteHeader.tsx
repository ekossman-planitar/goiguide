'use client'

import Image from 'next/image'
import {useEffect, useId, useRef, useState} from 'react'
import {Button} from '@/components/ui/Button'
import {Container} from '@/components/ui/Container'
import {SmartLink} from '@/components/ui/SmartLink'
import {ChevronDown, CloseIcon, MenuIcon} from '@/components/ui/icons'
import {cn} from '@/lib/cn'
import {headerButtons, mainNav, type NavItem} from '@/lib/navigation'

/** Sticky site header: logo, main nav with dropdowns, and the two action buttons. */
export function SiteHeader() {
  const [mobileOpen, setMobileOpen] = useState(false)

  return (
    <header className="sticky top-0 z-40 border-b border-line bg-white/95 backdrop-blur">
      <Container className="flex h-20 items-center justify-between gap-6">
        {/* Native <a> on purpose: full page loads keep GTM triggers working */}
        {/* eslint-disable-next-line @next/next/no-html-link-for-pages */}
        <a href="/" className="shrink-0" aria-label="iGUIDE home">
          {/* Drop the logo file at public/logo.svg */}
          <Image src="/logo.svg" alt="iGUIDE" width={170} height={34} priority className="h-8 w-auto" />
        </a>

        <nav aria-label="Main" className="hidden lg:block">
          <ul className="flex items-center gap-1">
            {mainNav.map((item) => (
              <DesktopNavItem key={item.label} item={item} />
            ))}
          </ul>
        </nav>

        <div className="hidden items-center gap-3 lg:flex">
          <Button href={headerButtons.findPro.href} variant="secondary">
            {headerButtons.findPro.label}
          </Button>
          <Button href={headerButtons.shop.href}>{headerButtons.shop.label}</Button>
        </div>

        <button
          type="button"
          className="-mr-2 rounded-md p-2 text-ink lg:hidden"
          aria-expanded={mobileOpen}
          aria-controls="mobile-nav"
          aria-label={mobileOpen ? 'Close menu' : 'Open menu'}
          onClick={() => setMobileOpen((open) => !open)}
        >
          {mobileOpen ? <CloseIcon /> : <MenuIcon />}
        </button>
      </Container>

      {mobileOpen && <MobileNav />}
    </header>
  )
}

function DesktopNavItem({item}: {item: NavItem}) {
  const [open, setOpen] = useState(false)
  const ref = useRef<HTMLLIElement>(null)
  const panelId = useId()

  // Close on outside click and Escape
  useEffect(() => {
    if (!open) return
    const onPointer = (e: PointerEvent) => {
      if (!ref.current?.contains(e.target as Node)) setOpen(false)
    }
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setOpen(false)
        ref.current?.querySelector('button')?.focus()
      }
    }
    document.addEventListener('pointerdown', onPointer)
    document.addEventListener('keydown', onKey)
    return () => {
      document.removeEventListener('pointerdown', onPointer)
      document.removeEventListener('keydown', onKey)
    }
  }, [open])

  const linkClass = 'flex items-center gap-1 rounded-md px-3 py-2 text-[17px] text-ink hover:text-primary'

  if (!item.children) {
    return (
      <li>
        <SmartLink href={item.href ?? '#'} className={linkClass}>
          {item.label}
        </SmartLink>
      </li>
    )
  }

  return (
    <li
      ref={ref}
      className="relative"
      onPointerEnter={(e) => e.pointerType === 'mouse' && setOpen(true)}
      onPointerLeave={(e) => e.pointerType === 'mouse' && setOpen(false)}
      onBlur={(e) => {
        if (!e.currentTarget.contains(e.relatedTarget as Node)) setOpen(false)
      }}
    >
      <button
        type="button"
        className={linkClass}
        aria-expanded={open}
        aria-controls={panelId}
        onClick={() => setOpen((v) => !v)}
      >
        {item.label}
        <ChevronDown className={cn('transition-transform', open && 'rotate-180')} />
      </button>
      {/* pt-2 bridges the gap so the pointer can travel into the panel */}
      <div id={panelId} hidden={!open} className="absolute left-0 top-full pt-2">
        <ul className="min-w-64 rounded-xl border border-line bg-white p-2 shadow-xl shadow-black/5">
          {item.children.map((child) => (
            <li key={child.href + child.label}>
              <SmartLink
                href={child.href}
                className="block rounded-lg px-3 py-2 text-[15px] text-body hover:bg-surface hover:text-primary"
              >
                {child.label}
              </SmartLink>
            </li>
          ))}
        </ul>
      </div>
    </li>
  )
}

function MobileNav() {
  return (
    <nav id="mobile-nav" aria-label="Main" className="border-t border-line bg-white lg:hidden">
      <Container className="max-h-[calc(100svh-5rem)] overflow-y-auto py-4">
        <ul className="divide-y divide-line">
          {mainNav.map((item) =>
            item.children ? (
              <li key={item.label}>
                <details className="group">
                  <summary className="flex cursor-pointer list-none items-center justify-between py-3 text-lg text-ink [&::-webkit-details-marker]:hidden">
                    {item.label}
                    <ChevronDown className="transition-transform group-open:rotate-180" />
                  </summary>
                  <ul className="pb-3">
                    {item.children.map((child) => (
                      <li key={child.href + child.label}>
                        <SmartLink href={child.href} className="block py-2 pl-3 text-body">
                          {child.label}
                        </SmartLink>
                      </li>
                    ))}
                  </ul>
                </details>
              </li>
            ) : (
              <li key={item.label}>
                <SmartLink href={item.href ?? '#'} className="block py-3 text-lg text-ink">
                  {item.label}
                </SmartLink>
              </li>
            ),
          )}
        </ul>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <Button href={headerButtons.findPro.href} variant="secondary">
            {headerButtons.findPro.label}
          </Button>
          <Button href={headerButtons.shop.href}>{headerButtons.shop.label}</Button>
        </div>
      </Container>
    </nav>
  )
}
