import type {ComponentPropsWithoutRef, ElementType} from 'react'
import {cn} from '@/lib/cn'

type ContainerProps<T extends ElementType> = {as?: T} & ComponentPropsWithoutRef<T>

/** Centred page-width wrapper with responsive side padding. */
export function Container<T extends ElementType = 'div'>({as, className, ...props}: ContainerProps<T>) {
  const Tag = as ?? 'div'
  return <Tag className={cn('mx-auto w-full max-w-[1320px] px-4 sm:px-6 lg:px-8', className)} {...props} />
}
