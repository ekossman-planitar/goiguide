import {Button} from '@/components/ui/Button'
import {FallbackImage} from '@/components/ui/FallbackImage'
import {cn} from '@/lib/cn'
import {CheckList} from './CheckList'
import type {Img} from './types'

export type Deliverable = {
  title: string
  /** e.g. "Best for real estate listings…" */
  summary?: string
  image: Img
  includesLabel?: string
  includes: string[]
  /** e.g. "Requires: iGUIDE Standard or Premium" */
  note?: string
  cta?: {label: string; href: string; newTab?: boolean}
}

const cols = {2: 'md:grid-cols-2', 3: 'md:grid-cols-2 lg:grid-cols-3', 4: 'md:grid-cols-2 xl:grid-cols-4'}

/** Product/deliverable cards: image, summary, checklist, requirement note and a sample link. */
export function DeliverableCards({items, columns = 4}: {items: Deliverable[]; columns?: 2 | 3 | 4}) {
  return (
    <ul className={cn('grid gap-6', cols[columns])}>
      {items.map((item) => (
        <li
          key={item.title}
          className="flex flex-col rounded-2xl border border-[#e7edf6] bg-white p-6 shadow-[0_2px_4px_rgba(0,0,0,0.075)]"
        >
          <h3 className="text-xl leading-7 font-bold text-ink">{item.title}</h3>
          {item.summary && <p className="mt-2 text-base leading-6 text-muted">{item.summary}</p>}
          <FallbackImage
            src={item.image.src}
            alt={item.image.alt}
            width={item.image.width ?? 462}
            height={item.image.height ?? 346}
            sizes="(min-width: 1280px) 25vw, (min-width: 768px) 50vw, 100vw"
            className="mt-5 h-auto w-full rounded-xl"
            fallback={<div className="mt-5 aspect-[4/3] w-full rounded-xl bg-surface" />}
          />
          {item.includesLabel && <p className="mt-6 text-sm font-semibold text-ink">{item.includesLabel}</p>}
          <CheckList items={item.includes} className={item.includesLabel ? 'mt-3' : 'mt-6'} />
          <div className="mt-auto pt-6">
            {item.note && <p className="text-sm leading-5 font-medium text-muted">{item.note}</p>}
            {item.cta && (
              <Button href={item.cta.href} variant="secondary" size="lg" className="mt-4 w-full" newTab={item.cta.newTab}>
                {item.cta.label}
              </Button>
            )}
          </div>
        </li>
      ))}
    </ul>
  )
}
