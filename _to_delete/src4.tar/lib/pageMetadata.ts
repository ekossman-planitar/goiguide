import type {Metadata} from 'next'

/** Title, description, canonical and Open Graph for a static page (values copied from the live page). */
export function pageMetadata({title, description, path, ogImage}: {title: string; description: string; path: string; ogImage?: string}): Metadata {
  return {
    title,
    description,
    alternates: {canonical: path},
    openGraph: {title, description, url: path, siteName: 'iGUIDE', type: 'website', images: ogImage ? [ogImage] : undefined},
    twitter: {card: 'summary_large_image', title, description, images: ogImage ? [ogImage] : undefined},
  }
}
