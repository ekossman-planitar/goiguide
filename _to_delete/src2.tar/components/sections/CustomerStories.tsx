'use client'

import {FallbackImage} from '@/components/ui/FallbackImage'
import {useCallback, useEffect, useRef, useState} from 'react'
import {Container} from '@/components/ui/Container'
import {SectionHeading} from '@/components/ui/SectionHeading'
import {SmartLink} from '@/components/ui/SmartLink'
import {ArrowRight, ChevronLeft, ChevronRight} from '@/components/ui/icons'
import {cn} from '@/lib/cn'

export type StoryCard = {
  quote: string
  name: string
  role: string
  company: string
  href: string
  /** Path in /public; the company name shows if the file is missing */
  logo: string
}

type Props = {
  heading: string
  subheading?: string
  link?: {label: string; href: string}
  stories: StoryCard[]
}

/** Customer quotes in a carousel: 3 visible on desktop, 2 on tablet, 1 on mobile. */
export function CustomerStories({heading, subheading, link, stories}: Props) {
  const trackRef = useRef<HTMLUListElement>(null)
  const [canPrev, setCanPrev] = useState(false)
  const [canNext, setCanNext] = useState(false)

  const update = useCallback(() => {
    const el = trackRef.current
    if (!el) return
    setCanPrev(el.scrollLeft > 4)
    setCanNext(el.scrollLeft + el.clientWidth < el.scrollWidth - 4)
  }, [])

  useEffect(() => {
    const el = trackRef.current
    if (!el) return
    update()
    el.addEventListener('scroll', update, {passive: true})
    const observer = new ResizeObserver(update)
    observer.observe(el)
    return () => {
      el.removeEventListener('scroll', update)
      observer.disconnect()
    }
  }, [update])

  // Move by one card
  const move = (direction: 1 | -1) => {
    const el = trackRef.current
    const card = el?.querySelector('li')
    if (!el || !card) return
    const gap = parseFloat(getComputedStyle(el).columnGap) || 0
    el.scrollBy({left: direction * (card.offsetWidth + gap), behavior: 'smooth'})
  }

  return (
    <section className="bg-sky py-16 lg:py-[60px]">
      <Container>
        <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
          <SectionHeading heading={heading} subheading={subheading} className="max-w-2xl" />
          <div className="flex shrink-0 items-center gap-4">
            {link && (
              <SmartLink href={link.href} className="group inline-flex items-center gap-1.5 font-semibold text-primary">
                {link.label}
                <ArrowRight width={16} height={16} className="transition-transform group-hover:translate-x-1" />
              </SmartLink>
            )}
            <div className="flex gap-2">
              <ArrowButton label="Previous stories" disabled={!canPrev} onClick={() => move(-1)}>
                <ChevronLeft width={20} height={20} />
              </ArrowButton>
              <ArrowButton label="Next stories" disabled={!canNext} onClick={() => move(1)}>
                <ChevronRight width={20} height={20} />
              </ArrowButton>
            </div>
          </div>
        </div>

        <ul
          ref={trackRef}
          aria-label="Customer stories"
          className="-mx-4 mt-10 flex snap-x snap-mandatory gap-6 overflow-x-auto scroll-px-4 px-4 pb-4 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
        >
          {stories.map((story) => (
            <li
              key={story.href}
              className="flex w-[85%] shrink-0 snap-start sm:w-[calc((100%-1.5rem)/2)] lg:w-[calc((100%-3rem)/3)]"
            >
              <StoryCardView story={story} />
            </li>
          ))}
        </ul>
      </Container>
    </section>
  )
}

function StoryCardView({story}: {story: StoryCard}) {
  return (
    <figure className="group flex w-full flex-col rounded-2xl border border-[#e7edf6] bg-white p-8 shadow-[0_2px_4px_rgba(0,0,0,0.075)] transition-shadow hover:shadow-lg">
      <div className="flex h-10 items-center">
        <FallbackImage
          src={story.logo}
          alt={story.company}
          width={160}
          height={40}
          className="h-10 w-auto max-w-[160px] object-contain object-left"
          fallback={<span className="text-lg font-bold text-ink">{story.company}</span>}
        />
      </div>

      <blockquote className="mt-8 flex-1">
        <p className="text-2xl leading-[1.35] font-semibold text-ink">
          <span aria-hidden className="mr-1 text-brand">“</span>
          {story.quote}
          <span aria-hidden className="text-brand">”</span>
        </p>
      </blockquote>

      <figcaption className="mt-8 flex items-end justify-between gap-4 border-t border-line pt-6">
        <div>
          <p className="font-semibold text-ink">{story.name}</p>
          <p className="text-sm leading-5 text-muted">
            {story.role}, {story.company}
          </p>
        </div>
        <SmartLink
          href={story.href}
          className="inline-flex shrink-0 items-center gap-1 text-sm font-semibold text-primary"
          aria-label={`Read ${story.company}'s story`}
        >
          Read story
          <ArrowRight width={14} height={14} className="transition-transform group-hover:translate-x-1" />
        </SmartLink>
      </figcaption>
    </figure>
  )
}

function ArrowButton({
  label,
  disabled,
  onClick,
  children,
}: {
  label: string
  disabled: boolean
  onClick: () => void
  children: React.ReactNode
}) {
  return (
    <button
      type="button"
      aria-label={label}
      disabled={disabled}
      onClick={onClick}
      className={cn(
        'flex h-11 w-11 items-center justify-center rounded-full border border-primary bg-white text-primary transition-colors',
        disabled ? 'cursor-not-allowed opacity-35' : 'hover:bg-primary hover:text-white',
      )}
    >
      {children}
    </button>
  )
}
