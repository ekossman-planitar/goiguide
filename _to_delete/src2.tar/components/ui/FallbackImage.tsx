'use client'

import Image, {type ImageProps} from 'next/image'
import {useState, type ReactNode} from 'react'

/**
 * next/image that shows `fallback` instead if the file fails to load
 * (e.g. an image not yet added to /public).
 */
export function FallbackImage({fallback = null, ...props}: ImageProps & {fallback?: ReactNode}) {
  const [failed, setFailed] = useState(false)
  if (failed) return <>{fallback}</>
  // eslint-disable-next-line jsx-a11y/alt-text -- alt is passed through props
  return <Image {...props} onError={() => setFailed(true)} />
}
