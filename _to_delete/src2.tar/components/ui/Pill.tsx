import {ArrowRight} from './icons'
import {SmartLink} from './SmartLink'

/** Cream pill link, as used above the hero and section headings on the live site. */
export function Pill({label, href}: {label: string; href: string}) {
  return (
    <SmartLink
      href={href}
      className="inline-flex items-center gap-2 rounded-[28px] bg-cream px-3 py-2 text-xs leading-[18px] font-semibold text-ink transition-opacity hover:opacity-85"
    >
      {label}
      <ArrowRight width={14} height={14} />
    </SmartLink>
  )
}
