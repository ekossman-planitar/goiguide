'use client'

import {useState} from 'react'
import {Button} from '@/components/ui/Button'
import {Container} from '@/components/ui/Container'
import {SectionHeading} from '@/components/ui/SectionHeading'
import {ChevronDown} from '@/components/ui/icons'
import {cn} from '@/lib/cn'
import {
  ArrowLink,
  CurrencySwitch,
  IndustryFilter,
  PackageDetails,
  CameraImage,
  PackageImage,
  PriceTag,
  usePricingFilters,
  type PricingData,
} from './shared'

/** Pricing: camera on the left (1/3), packages as an expandable list on the right (2/3). */
export function PricingSideBySide({data}: {data: PricingData}) {
  const {currency, setCurrency, industry, setIndustry, visible} = usePricingFilters(data.packages)
  const [open, setOpen] = useState<string | null>(null)
  const {camera} = data

  return (
    <section className="py-10 lg:py-[60px]">
      <Container>
        <div className="rounded-2xl bg-surface px-4 py-12 sm:px-8 lg:px-12">
          <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
            <SectionHeading heading={data.heading} subheading={data.subheading} className="lg:flex-1" />
            <CurrencySwitch value={currency} onChange={setCurrency} />
          </div>

          <div className="mt-10 grid gap-6 lg:grid-cols-3">
            {/* Step 1: camera */}
            <article className="flex flex-col rounded-2xl bg-white p-8 shadow-sm">
              <p className="text-sm font-semibold text-primary">Step 1 · Get the camera</p>
              <h3 className="mt-1 text-2xl font-bold text-ink">{camera.name}</h3>
              <div className="relative my-6 h-56">
                <CameraImage src={camera.image} alt={camera.name} sizes="(min-width: 1024px) 25vw, 80vw" />
              </div>
              <PriceTag prices={camera.prices} currency={currency} size="lg" />
              <p className="mt-4 text-body">{camera.intro}</p>
              <div className="mt-auto pt-6">
                <Button href={camera.cta.href} size="lg" className="w-full">
                  {camera.cta.label}
                </Button>
                <ArrowLink href={camera.shopLink.href} className="mt-4">
                  {camera.shopLink.label}
                </ArrowLink>
              </div>
            </article>

            {/* Step 2: packages */}
            <div className="rounded-2xl bg-white p-6 shadow-sm lg:col-span-2 lg:p-8">
              <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <p className="text-sm font-semibold text-primary">Step 2 · Choose a package</p>
                  <h3 className="mt-1 text-2xl font-bold text-ink">iGUIDE packages</h3>
                </div>
                <IndustryFilter value={industry} onChange={setIndustry} variant="select" />
              </div>

              <ul className="mt-6 divide-y divide-line border-y border-line" aria-live="polite">
                {visible.map((pkg) => {
                  const isOpen = open === pkg.id
                  return (
                    <li key={pkg.id}>
                      <button
                        type="button"
                        aria-expanded={isOpen}
                        aria-controls={`pkg-${pkg.id}`}
                        onClick={() => setOpen(isOpen ? null : pkg.id)}
                        className="flex w-full items-center gap-4 py-4 text-left"
                      >
                        <span className="flex-1 text-lg font-semibold text-ink">{pkg.name}</span>
                        <span className="hidden text-sm text-muted sm:inline">{pkg.priceLabel}</span>
                        <span className="w-28 text-right text-lg font-bold text-ink tabular-nums">
                          {pkg.prices[currency]} <span className="text-xs font-semibold">{currency}</span>
                        </span>
                        <ChevronDown className={cn('shrink-0 text-primary transition-transform', isOpen && 'rotate-180')} />
                      </button>
                      <div id={`pkg-${pkg.id}`} hidden={!isOpen} className="pb-6">
                        <div className="grid gap-6 sm:grid-cols-[200px_1fr]">
                          <PackageImage src={pkg.image} alt={pkg.name} className="aspect-[4/3]" />
                          <div>
                            <PackageDetails pkg={pkg} />
                            {pkg.sample && (
                              <ArrowLink href={pkg.sample.href} className="mt-4">
                                {pkg.sample.label}
                              </ArrowLink>
                            )}
                          </div>
                        </div>
                      </div>
                    </li>
                  )
                })}
              </ul>
              <ArrowLink href={data.allLink.href} className="mt-6 text-base">
                {data.allLink.label}
              </ArrowLink>
            </div>
          </div>
        </div>
      </Container>
    </section>
  )
}
